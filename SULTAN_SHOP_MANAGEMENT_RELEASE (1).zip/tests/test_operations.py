"""Integration tests for core inventory, sales, returns and access boundaries."""
import sys
from pathlib import Path
from fastapi.testclient import TestClient

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def setup_client(tmp_path, monkeypatch):
    from app import main
    monkeypatch.setattr(main, "DB", tmp_path / "operations.db")
    main.init_db()
    return main, TestClient(main.app)


def owner_login(client):
    r = client.post("/api/login", json={"username": "admin", "password": "ChangeMe123!"})
    assert r.status_code == 200, r.text


def test_discounted_partial_return_reconciles_stock_and_refund(tmp_path, monkeypatch):
    main, client = setup_client(tmp_path, monkeypatch)
    owner_login(client)
    branch = client.get("/api/branches").json()[0]["id"]
    product = client.post("/api/products", json={
        "name": "Test item", "purchase_price": 40, "selling_price": 100,
        "quantity": 10, "min_stock": 1
    })
    assert product.status_code == 200, product.text
    pid = product.json()["id"]

    sale = client.post("/api/sales", json={
        "branch_id": branch, "discount": 20, "paid": 180,
        "items": [{"product_id": pid, "qty": 2}]
    })
    assert sale.status_code == 200, sale.text
    sid = sale.json()["id"]
    detail = client.get(f"/api/sales/{sid}").json()
    item_id = detail["items"][0]["id"]

    returned = client.post(f"/api/sales/{sid}/returns", json={
        "sale_item_id": item_id, "qty": 1, "refund_method": "نقدي", "reason": "test"
    })
    assert returned.status_code == 200, returned.text
    # 20% invoice discount is allocated proportionally to the returned item.
    assert returned.json()["refund_amount"] == 90

    excessive = client.post(f"/api/sales/{sid}/returns", json={
        "sale_item_id": item_id, "qty": 2, "refund_method": "نقدي"
    })
    assert excessive.status_code == 400

    products = client.get("/api/products").json()
    assert next(p for p in products if p["id"] == pid)["quantity"] == 9

    bad_method = client.post(f"/api/sales/{sid}/returns", json={
        "sale_item_id": item_id, "qty": 0.25, "refund_method": "unknown"
    })
    assert bad_method.status_code == 400


def test_employee_permissions_and_branch_scope_are_enforced(tmp_path, monkeypatch):
    main, owner = setup_client(tmp_path, monkeypatch)
    owner_login(owner)
    branches = owner.get("/api/branches").json()
    branch1 = branches[0]["id"]
    branch2 = owner.post("/api/branches", json={"name": "Branch Two"}).json()["id"]

    created = owner.post("/api/users", json={
        "username": "cashier", "password": "StrongPass123!", "full_name": "Cashier",
        "role": "employee", "branch_id": branch1
    })
    assert created.status_code == 200, created.text
    uid = created.json()["id"]
    saved = owner.patch(f"/api/users/{uid}/permissions", json={"permissions": ["sales"]})
    assert saved.status_code == 200, saved.text

    employee = TestClient(main.app)
    login = employee.post("/api/login", json={"username": "cashier", "password": "StrongPass123!"})
    assert login.status_code == 200, login.text
    assert employee.get("/api/sales").status_code == 200
    assert employee.get("/api/products").status_code == 403
    assert employee.get("/api/branches").json() == [{"id": branch1, "name": "الفرع الرئيسي", "active": 1}]

    # A branch ID supplied by the client cannot override the employee's assigned branch.
    forged = employee.post("/api/sales", json={
        "branch_id": branch2, "items": [{"product_id": 1, "qty": 1}]
    })
    assert forged.status_code == 403


def test_transfer_requires_owner_decision_and_is_applied_once(tmp_path, monkeypatch):
    main, client = setup_client(tmp_path, monkeypatch)
    owner_login(client)
    b1 = client.get("/api/branches").json()[0]["id"]
    b2 = client.post("/api/branches", json={"name": "Receiving"}).json()["id"]
    p = client.post("/api/products", json={"name": "Transfer item", "quantity": 8,
        "purchase_price": 2, "selling_price": 5}).json()

    request = client.post("/api/transfers", json={"from_branch": b1, "to_branch": b2,
        "product_id": p["id"], "qty": 3})
    assert request.status_code == 200, request.text
    assert request.json()["status"] == "pending"
    before = {x["id"]: x["quantity"] for x in client.get("/api/products").json()}
    assert before[p["id"]] == 8

    decision = client.post(f"/api/transfers/{request.json()['id']}/decision", json={"approve": True})
    assert decision.status_code == 200, decision.text
    after = {x["id"]: x["quantity"] for x in client.get("/api/products").json()}
    assert after[p["id"]] == 8  # owner aggregate view remains conserved

    duplicate = client.post(f"/api/transfers/{request.json()['id']}/decision", json={"approve": True})
    assert duplicate.status_code == 409


def test_production_configuration_rejects_missing_secret(tmp_path):
    import os, subprocess
    env = os.environ.copy()
    env["APP_ENV"] = "production"
    env.pop("SULTAN_SECRET_KEY", None)
    result = subprocess.run([sys.executable, "-c", "import app.main"], cwd=PROJECT_ROOT,
                            env=env, capture_output=True, text=True)
    assert result.returncode != 0
    assert "SULTAN_SECRET_KEY" in result.stderr


def test_production_bootstrap_requires_custom_owner_password(tmp_path):
    import os, subprocess
    env = os.environ.copy()
    env["APP_ENV"] = "production"
    env["SULTAN_SECRET_KEY"] = "a-unique-production-secret-that-is-long-enough-123456"
    env.pop("SULTAN_INITIAL_ADMIN_PASSWORD", None)
    env["SULTAN_DB_PATH"] = str(tmp_path / "production.db")
    result = subprocess.run([sys.executable, "-c", "import app.main"], cwd=PROJECT_ROOT,
                            env=env, capture_output=True, text=True)
    assert result.returncode != 0
    assert "SULTAN_INITIAL_ADMIN_PASSWORD" in result.stderr


def test_health_endpoint_and_initial_admin_password_override(tmp_path, monkeypatch):
    import os, subprocess
    from app import main
    monkeypatch.setattr(main, "DB", tmp_path / "health.db")
    monkeypatch.setattr(main, "APP_ENV", "development")
    monkeypatch.setattr(main, "INITIAL_ADMIN_PASSWORD", "LocalAdminPass123!")
    main.init_db()
    client = TestClient(main.app)
    assert client.get("/healthz").json() == {"status": "ok"}
    login = client.post("/api/login", json={"username": "admin", "password": "LocalAdminPass123!"})
    assert login.status_code == 200


def test_stocktake_audit_and_report_exports(tmp_path, monkeypatch):
    main, client = setup_client(tmp_path, monkeypatch)
    owner_login(client)
    branch = client.get("/api/branches").json()[0]["id"]
    product = client.post("/api/products", json={"name": "Counted", "quantity": 5,
        "purchase_price": 3, "selling_price": 7}).json()
    adjusted = client.post("/api/stocktake/adjust", json={"product_id": product["id"],
        "branch_id": branch, "actual_quantity": 4, "reason": "physical count"})
    assert adjusted.status_code == 200, adjusted.text
    assert adjusted.json()["difference"] == -1
    movements = client.get("/api/stock-movements").json()
    assert any(x["kind"] == "stocktake" and x["quantity"] == -1 for x in movements)
    csv_report = client.get("/api/reports/export.csv")
    assert csv_report.status_code == 200 and "text/csv" in csv_report.headers["content-type"]
    xlsx_report = client.get("/api/reports/export.xlsx")
    assert xlsx_report.status_code == 200
    assert xlsx_report.content[:2] == b"PK"
