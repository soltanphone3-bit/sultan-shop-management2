"""Focused smoke tests for authentication and security response headers.
Run with: pytest -q
"""
import sys
from pathlib import Path
from fastapi.testclient import TestClient

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def test_authentication_and_security_controls(tmp_path, monkeypatch):
    from app import main

    monkeypatch.setattr(main, "DB", tmp_path / "test_sultan.db")
    main.init_db()
    client = TestClient(main.app)

    # Security headers are present on both the app shell and API responses.
    home = client.get("/")
    assert home.status_code == 200
    assert home.headers["x-content-type-options"] == "nosniff"
    assert home.headers["x-frame-options"] == "DENY"
    assert "camera=(self)" in home.headers["permissions-policy"]

    # The initial owner can authenticate and receives an HttpOnly session cookie.
    login = client.post("/api/login", json={"username": "admin", "password": "ChangeMe123!"})
    assert login.status_code == 200
    assert "httponly" in login.headers.get("set-cookie", "").lower()
    assert client.get("/api/me").status_code == 200
    assert client.get("/api/me").headers["cache-control"] == "no-store"

    # A failed password attempt is counted; after the threshold the IP/username pair is throttled.
    client.post("/api/logout")
    for _ in range(8):
        response = client.post("/api/login", json={"username": "admin", "password": "wrong-password"})
        assert response.status_code == 401
    blocked = client.post("/api/login", json={"username": "admin", "password": "ChangeMe123!"})
    assert blocked.status_code == 429

    # A different username has an independent attempt bucket.
    other = client.post("/api/login", json={"username": "not-admin", "password": "wrong-password"})
    assert other.status_code == 401
